# CryptoInfo
1. User can view latest BTC price.
2. User can view last 30 days avaibale datas.

# How to build in ios
1. npm install
2. cd /ios && pod install && cd ..
3. react-native run-ios

# How to build in android
1. npm install
2. react-native run-android

# Note
1. Screenshot attached of the app.

# future feature
1. Can you different like last 1, 7, 30 or 60 days.
2. Can add light or dark theme.
3. User input like managing add / remove .
