const images = {
    bitcoinIcon: require('./img/bitcoin.png'),
};

export default images;