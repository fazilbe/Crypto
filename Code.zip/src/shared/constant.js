/**
*
* constants.js
* Declare all Constant variable
*
* @author - Ahamed
* @date   - 20 September 2020
*
***/

// DECLARE GENERIC CONSTANT
export const GENERIC = {
}

export const URL = {
	BTC_CURRENT: "https://api.coindesk.com/v1/bpi/currentprice/USD.json",
	BTC_HISTORY: "https://api.coindesk.com/v1/bpi/historical/close.json",//?start=2020-09-21&end=2020-08-22
}